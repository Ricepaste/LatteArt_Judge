# latte-art > 2023-10-10 11:51am
https://universe.roboflow.com/home-r23oa/latte-art

Provided by a Roboflow user
License: CC BY 4.0

