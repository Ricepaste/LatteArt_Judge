# Detecting Coffee and Tea > 2023-07-02 10:41pm
https://universe.roboflow.com/archisman-sengupta-j1ltg/detecting-coffee-and-tea

Provided by a Roboflow user
License: CC BY 4.0

